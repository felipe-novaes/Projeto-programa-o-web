const btnMobile = document.getElementById('btn-mobile');
const menu = document.getElementById('menu'); // Garante que temos acesso ao elemento do menu

// Função para alternar a visibilidade do menu
function toggleMenu(event) {
    if (event.type === 'touchstart') event.preventDefault(); // Previne o comportamento padrão no touchstart
    
    // Modifica a propriedade CSS para acionar a transição
    if (menu.style.display === "none" ||!menu.classList.contains('active')) {
        menu.style.display = "flex"; // Altera para 'flex' ou 'block' dependendo de sua necessidade
        menu.style.opacity = 0; // Começa com opacidade 0 para acionar a transição
        setTimeout(() => { // Aguarda um pouco antes de alternar a classe para dar tempo à transição começar
            menu.classList.add('active');
            menu.style.opacity = 1; // Define a opacidade final após a transição
        }, 10); // Ajuste o tempo conforme necessário
    } else {
        menu.style.opacity = 0; // Prepara a transição para voltar
        setTimeout(() => { // Aguarda um pouco antes de alternar a classe para dar tempo à transição terminar
            menu.classList.remove('active');
            menu.style.display = "none"; // Esconde o menu após a transição
        }, 500); // Ajuste o tempo conforme necessário
    }
}

// Adiciona os listeners de evento
btnMobile.addEventListener('click', toggleMenu);
btnMobile.addEventListener('touchstart', toggleMenu);
